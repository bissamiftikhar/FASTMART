package com.livisync.smd_a2.activities;

import android.os.Bundle;
import android.widget.TableLayout;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.viewpager2.widget.ViewPager2;

import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;
import com.livisync.smd_a2.R;
import com.livisync.smd_a2.adapters.LoginPagerAdapter;

public class LoginActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);

        ViewPager2 viewpager=findViewById(R.id.viewPager);
        LoginPagerAdapter adapter=new LoginPagerAdapter(this);
        viewpager.setAdapter(adapter);

        TabLayout tabLayout=findViewById(R.id.tabLayout);

        new TabLayoutMediator(tabLayout,viewpager,(tab,position)->{
            if(position==0){
                tab.setText("Log in");
            }
            else{
                tab.setText("Sign up");
            }
        }).attach();
    }
}