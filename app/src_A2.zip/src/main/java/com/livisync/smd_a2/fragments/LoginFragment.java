package com.livisync.smd_a2.fragments;

import static android.content.Context.MODE_PRIVATE;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.livisync.smd_a2.R;
import com.livisync.smd_a2.activities.MainActivity;


public class LoginFragment extends Fragment {
    private SharedPreferences prefs;
    private EditText etemail,etpassword;
    private Button btnlogin;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_login, container, false);
        prefs=requireActivity().getSharedPreferences("app.settings",MODE_PRIVATE);
        etemail=view.findViewById(R.id.etEmail);
        etpassword=view.findViewById(R.id.etPassword);
        btnlogin=view.findViewById(R.id.btnLogin);
        btnlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email=etemail.getText().toString().trim();
                String password=etpassword.getText().toString().trim();
                if(email.isEmpty()){
                    etemail.setError("email is required");
                }
                if(password.isEmpty()){
                    etemail.setError("email is required");
                }
                if(!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()){
                    etemail.setError("wrong email format");
                }
                String savedEmail = prefs.getString("user.email", "");
                String savedPassword = prefs.getString("user.password", "");

                if (email.equals(savedEmail) && password.equals(savedPassword)) {
                    SharedPreferences.Editor editor = prefs.edit();
                    editor.putBoolean("user.isLoggedIn", true);
                    editor.apply();

                    Intent intent = new Intent(requireActivity(), MainActivity.class);
                    startActivity(intent);
                    requireActivity().finish();
                } else {
                    Toast.makeText(requireActivity(), "Invalid credentials", Toast.LENGTH_SHORT).show();
                }
            }
        });
        return view;
    }
}