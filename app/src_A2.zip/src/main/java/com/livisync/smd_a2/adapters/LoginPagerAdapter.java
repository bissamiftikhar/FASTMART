package com.livisync.smd_a2.adapters;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;

import com.livisync.smd_a2.fragments.LoginFragment;
import com.livisync.smd_a2.fragments.SignUpFragment;

public class LoginPagerAdapter extends FragmentStateAdapter {
    public LoginPagerAdapter(FragmentActivity activty){
        super((activty));
    }

    @NonNull
    public Fragment createFragment(int position){
        if (position == 0) {
            return new LoginFragment();
        } else {
            return new SignUpFragment();
        }
    }
    public int getItemCount() {
        return 2;
    }
}
