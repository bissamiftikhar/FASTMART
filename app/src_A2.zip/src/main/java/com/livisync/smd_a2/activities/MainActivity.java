package com.livisync.smd_a2.activities;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.livisync.smd_a2.R;
import com.livisync.smd_a2.fragments.CartFragment;
import com.livisync.smd_a2.fragments.FavouritesFragment;
import com.livisync.smd_a2.fragments.HomeFragment;
import com.livisync.smd_a2.fragments.ProfileFragment;
import com.livisync.smd_a2.fragments.SearchFragment;

public class MainActivity extends AppCompatActivity {
    private BottomNavigationView bottomnavigationview;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        bottomnavigationview = findViewById(R.id.bottomNavigationView);
        loadFragment(new HomeFragment());
        bottomnavigationview.setOnItemSelectedListener(item->{
            int id=item.getItemId();
            if (id == R.id.nav_home) {
                loadFragment(new HomeFragment());
            } else if (id == R.id.nav_search) {
                loadFragment(new SearchFragment());
            } else if (id == R.id.nav_favourites) {
                loadFragment(new FavouritesFragment());
            } else if (id == R.id.nav_cart) {
                loadFragment(new CartFragment());
            } else if (id == R.id.nav_profile) {
                loadFragment(new ProfileFragment());
            }
            return true;
        });
    }
    private void loadFragment(Fragment fragment) {
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragmentContainer,fragment)
                .commit();
    }
}