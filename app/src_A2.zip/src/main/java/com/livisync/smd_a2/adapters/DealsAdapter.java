package com.livisync.smd_a2.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.livisync.smd_a2.R;
import com.livisync.smd_a2.models.Product;

import java.util.List;

public class DealsAdapter extends ArrayAdapter<Product> {

    private Context context;
    private List<Product> deals;

    public DealsAdapter(Context context, List<Product> deals) {
        super(context, 0, deals);
        this.context = context;
        this.deals = deals;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.item_deal, parent, false);
        }

        Product product = deals.get(position);

        TextView tvName = convertView.findViewById(R.id.tvDealName);
        TextView tvPrice = convertView.findViewById(R.id.tvDealPrice);
        TextView tvOriginal = convertView.findViewById(R.id.tvOriginalPrice);
        TextView tvDesc = convertView.findViewById(R.id.tvDealDescription);
        ImageView imgDeal = convertView.findViewById(R.id.imgDeal);

        tvName.setText(product.getName());
        tvPrice.setText("$" + product.getPrice());
        tvOriginal.setText("$" + product.getOriginalPrice());
        tvDesc.setText(product.getDescription());
        imgDeal.setImageResource(product.getImageResId());

        return convertView;
    }
}