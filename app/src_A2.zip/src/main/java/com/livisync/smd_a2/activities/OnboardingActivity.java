package com.livisync.smd_a2.activities;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import com.livisync.smd_a2.R;

public class OnboardingActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_onboarding);
        SharedPreferences prefs=getSharedPreferences("app.settings",MODE_PRIVATE);
        SharedPreferences.Editor editor=prefs.edit();
        editor.putBoolean("onboarding.shown",true);
        editor.apply();

        Button btnGetStarted=findViewById(R.id.btnGetStarted);
        btnGetStarted.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent=new Intent(OnboardingActivity.this,LoginActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }
}