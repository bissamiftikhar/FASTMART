package com.livisync.smd_a2.activities;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.livisync.smd_a2.R;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_splash);
        SharedPreferences prefs = getSharedPreferences("app.settings", MODE_PRIVATE);
        boolean onboardingShown=prefs.getBoolean("onboarding.shown",false);
        boolean isloggedin=prefs.getBoolean("user.isLoggedIn",false);
       new Handler(Looper.getMainLooper()).postDelayed(new Runnable(){
          public void run(){
              if(isloggedin){
                  Intent intent=new Intent(SplashActivity.this, MainActivity.class);
                  startActivity(intent);
                  finish();
              }
              else if (onboardingShown) {
                  startActivity(new Intent(SplashActivity.this, LoginActivity.class));
              }
              else {
                  startActivity(new Intent(SplashActivity.this, OnboardingActivity.class));
              }
              finish();
          }
       },2000);
    }
}