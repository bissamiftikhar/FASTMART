package com.livisync.smd_a2.fragments;

import static android.content.Context.MODE_PRIVATE;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ShareActionProvider;
import android.widget.Toast;

import com.livisync.smd_a2.R;
import com.livisync.smd_a2.activities.MainActivity;

public class SignUpFragment extends Fragment {

    private EditText etEmail, etPassword, etConfirmPassword;
    private Button btnSignUp;
    private SharedPreferences prefs;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_sign_up, container, false);
        prefs = requireActivity().getSharedPreferences("app.settings", Context.MODE_PRIVATE);
        etEmail=view.findViewById(R.id.etEmail);
        etPassword=view.findViewById(R.id.etPassword);
        etConfirmPassword=view.findViewById(R.id.etConfirmPassword);
        btnSignUp=view.findViewById(R.id.btnSignUp);
        btnSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = etEmail.getText().toString().trim();
                String password = etPassword.getText().toString().trim();
                String confirmPassword = etConfirmPassword.getText().toString().trim();
                if (email.isEmpty()) {
                    etEmail.setError("Email is required");
                    return;
                }
                if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                    etEmail.setError("Invalid email format");
                    return;
                }
                if (password.isEmpty()) {
                    etPassword.setError("Password is required");
                    return;
                }
                if (password.length() < 6) {
                    etPassword.setError("Password must be at least 6 characters");
                    return;
                }
                if (!password.equals(confirmPassword)) {
                    etConfirmPassword.setError("Passwords do not match");
                    return;
                }
                SharedPreferences.Editor editor=prefs.edit();

                editor.putString("user.email",email);
                editor.putString("user.password",password);
                editor.putBoolean("user.isLoggedIn",true);
                editor.apply();
                Toast.makeText(requireActivity(), "account created", Toast.LENGTH_SHORT).show();
                Intent intent=new Intent(requireActivity(), MainActivity.class);
                startActivity(intent);
                requireActivity().finish();
            }
        });

    return view;
    }
}